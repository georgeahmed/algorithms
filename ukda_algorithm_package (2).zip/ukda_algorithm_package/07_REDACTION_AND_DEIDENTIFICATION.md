---
algorithm_id: UKDA-ALG-007
title: Redaction and De-identification
version: 1.0.0
status: normative
owner: Data Protection and Release Engineering
depends_on:
  - 05_DOCUMENT_EXTRACTION_LANES.md
  - 06_MANUSCRIPT_DECIPHERING.md
last_updated: 2026-04-14
---

# ALGORITHM: Redaction and De-identification

## 1. Purpose

Detect and transform sensitive information across text, images, and structured data while preserving research utility and release safety.

## 2. Scope

Applies to all extracted content before external publication, open discovery, or movement out of controlled processing boundaries.

## 3. Inputs

- `CanonicalDocumentGraph`
- `AccessTier`
- `RedactionPolicy`
- `EntitySchema`
- `ReleaseRules`

## 4. Outputs

- `RestrictedMasterDerivative`
- `ResearchReleaseDerivative`
- `RedactionLedger`
- `EscalationQueue`
- `ResidualRiskAssessment`

## 5. Dependencies

- deterministic rules / pattern recognizers;
- `Presidio` (text, image, structured data);
- `GLiNER`;
- local LLM/VLM adjudicator;
- PDF/image burn-in and metadata-scrub tools.

## 6. Preconditions

- canonical graph exists;
- access tier assigned;
- release rules loaded.

## 7. Postconditions

- restricted master is stored with governance controls;
- release derivative contains irreversible redactions where required;
- hidden text layers and metadata are scrubbed from released redacted artifacts.

## 8. Invariants

1. Redaction MUST be layered, not single-engine.
2. Release derivative MUST NOT depend on hidden overlays alone.
3. Controlled-tier content MUST NOT be exposed through search snippets before release control.
4. Low-confidence redaction decisions MUST escalate.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `RULESET_VERSION` | deterministic identifier patterns |
| `PRESIDIO_THRESHOLD` | analyzer threshold |
| `GLINER_THRESHOLD` | entity detection threshold |
| `AMBIGUITY_REVIEW_THRESHOLD` | escalate if exceeded |
| `BURN_IN_REDACTIONS` | irreversible visual redaction |
| `STRIP_HIDDEN_TEXT_LAYERS` | remove hidden OCR text from release PDFs |
| `KEEP_RESTRICTED_MASTER` | always true in this design |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-007 RedactionAndDeidentification
REQUIRE CanonicalDocumentGraph, AccessTier, RedactionPolicy
ENSURE RestrictedMasterDerivative, ResearchReleaseDerivative, RedactionLedger

BEGIN
    CALL Audit("REDACTION_STARTED", CanonicalDocumentGraph.document_id)

    SET rule_hits <- CALL ApplyDeterministicRules(CanonicalDocumentGraph, RULESET_VERSION)
    SET presidio_hits <- CALL PresidioAnalyze(CanonicalDocumentGraph, PRESIDIO_THRESHOLD)
    SET gliner_hits <- CALL GLiNERAnalyze(CanonicalDocumentGraph, GLINER_THRESHOLD)

    SET merged_hits <- CALL MergeSensitiveEntityHits(rule_hits, presidio_hits, gliner_hits)

    FOR EACH entity_span IN merged_hits DO
        IF entity_span.ambiguity >= AMBIGUITY_REVIEW_THRESHOLD THEN
            SET adjudicated_span <- CALL LocalLLMOrVLMAdjudicate(entity_span)
        ELSE
            SET adjudicated_span <- entity_span
        END IF

        IF adjudicated_span.final_risk = "HIGH" AND
           adjudicated_span.confidence < AMBIGUITY_REVIEW_THRESHOLD THEN
            ESCALATE adjudicated_span TO HumanRedactionReviewQueue
        END IF

        EMIT RedactionDecision(adjudicated_span)
    END FOR

    SET restricted_master <- CALL BuildRestrictedMaster(
        CanonicalDocumentGraph,
        RedactionDecisionSet,
        preserve_reversibility = TRUE
    )

    SET research_release <- CALL BuildReleaseDerivative(
        CanonicalDocumentGraph,
        RedactionDecisionSet,
        burn_in = BURN_IN_REDACTIONS,
        strip_hidden_text = STRIP_HIDDEN_TEXT_LAYERS,
        scrub_metadata = TRUE
    )

    SET residual_risk <- CALL AssessResidualRisk(research_release)

    CALL Audit("REDACTION_COMPLETED", residual_risk.level)

    RETURN {
        RestrictedMasterDerivative = restricted_master,
        ResearchReleaseDerivative = research_release,
        RedactionLedger = RedactionDecisionSet,
        EscalationQueue,
        ResidualRiskAssessment = residual_risk
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | known identifier pattern | deterministic redaction |
| G2 | uncertain entity span | LLM/VLM adjudication |
| G3 | ambiguity remains high | human review |
| G4 | release artifact built | burn in and scrub hidden layers |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| rule/ML disagreement | preserve alternatives, adjudicate, escalate if needed |
| image-text mismatch | re-run image redaction path |
| hidden OCR layer remains | fail release build |
| metadata still contains identifiers | fail release build and scrub again |

## 13. Audit Events

- `REDACTION_STARTED`
- `ENTITY_HITS_MERGED`
- `REDACTION_ADJUDICATION_USED`
- `REDACTION_ESCALATED`
- `RESTRICTED_MASTER_BUILT`
- `RELEASE_DERIVATIVE_BUILT`
- `REDACTION_COMPLETED`

## 14. Human Escalation Conditions

Escalate only for:

- unresolved high-risk spans;
- signatures, marginalia, or handwritten identifiers with low confidence;
- records where release risk materially depends on interpretation;
- controlled outputs requested for external release.

## 15. Security / Privacy / Compliance Notes

- Presidio supports detection/redaction/anonymization for text, images, and structured data, but automated detection is not guaranteed to catch everything, which is why explicit review gates remain necessary.  
  References: [R-PRESIDIO](99_REFERENCE_MAP.md#r-presidio), [R-PRESIDIO-IMAGE](99_REFERENCE_MAP.md#r-presidio-image)
- GLiNER offers lightweight local entity extraction suitable for on-prem deployments.  
  Reference: [R-GLINER](99_REFERENCE_MAP.md#r-gliner)
- ICO research safeguards emphasize data minimisation, anonymisation, and pseudonymisation as appropriate safeguards.  
  Reference: [R-ICO-SAFEGUARDS](99_REFERENCE_MAP.md#r-ico-safeguards)
- Controlled-output release aligns with SecureLab-style Safe Outputs / SDC review.  
  References: [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs), [R-SECURELAB-FAQ](99_REFERENCE_MAP.md#r-securelab-faq)

## 16. Metrics

- `redaction_recall`
- `redaction_precision`
- `high_risk_miss_rate`
- `review_escalation_rate`
- `release_build_failure_rate`

## 17. References

- [R-PRESIDIO](99_REFERENCE_MAP.md#r-presidio)
- [R-PRESIDIO-IMAGE](99_REFERENCE_MAP.md#r-presidio-image)
- [R-GLINER](99_REFERENCE_MAP.md#r-gliner)
- [R-ICO-SAFEGUARDS](99_REFERENCE_MAP.md#r-ico-safeguards)
- [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs)
- [R-SECURELAB-FAQ](99_REFERENCE_MAP.md#r-securelab-faq)
