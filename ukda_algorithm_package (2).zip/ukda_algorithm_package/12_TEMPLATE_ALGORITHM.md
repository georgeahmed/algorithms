---
algorithm_id: UKDA-ALG-XXX
title: <Replace with algorithm title>
version: 0.1.0
status: draft
owner: <Replace with owner/team>
depends_on:
  - <file1.md>
  - <file2.md>
last_updated: YYYY-MM-DD
---

# ALGORITHM: <Replace with algorithm title>

## 1. Purpose

<State the objective in one paragraph.>

## 2. Scope

<Define what is in and out of scope.>

## 3. Inputs

- `<input_1>`
- `<input_2>`

## 4. Outputs

- `<output_1>`
- `<output_2>`

## 5. Dependencies

- `<dependency_1>`
- `<dependency_2>`

## 6. Preconditions

- `<precondition_1>`
- `<precondition_2>`

## 7. Postconditions

- `<postcondition_1>`
- `<postcondition_2>`

## 8. Invariants

1. `<invariant_1>`
2. `<invariant_2>`

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `<PARAM_A>` | `<meaning>` |
| `<PARAM_B>` | `<meaning>` |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-XXX <ShortName>
REQUIRE <required inputs>
ENSURE <guaranteed outputs>

BEGIN
    ASSERT <validation>
    CALL Audit("<EVENT_NAME>", <context>)

    FOR EACH <item> IN <collection> DO
        IF <condition> THEN
            CALL <action>()
        ELSE
            ESCALATE <item> TO <queue>
        END IF
    END FOR

    RETURN <outputs>
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | `<condition>` | `<action>` |
| G2 | `<condition>` | `<action>` |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| `<failure>` | `<recovery>` |
| `<failure>` | `<recovery>` |

## 13. Audit Events

- `<EVENT_1>`
- `<EVENT_2>`

## 14. Human Escalation Conditions

- `<condition_1>`
- `<condition_2>`

## 15. Security / Privacy / Compliance Notes

- `<control_1>`
- `<control_2>`

## 16. Metrics

- `<metric_1>`
- `<metric_2>`

## 17. References

- `[R-REF-1](99_REFERENCE_MAP.md#r-ref-1)`
- `[R-REF-2](99_REFERENCE_MAP.md#r-ref-2)`
