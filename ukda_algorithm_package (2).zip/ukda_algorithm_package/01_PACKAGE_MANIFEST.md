---
document_id: UKDA-ALG-MANIFEST-001
title: Package Manifest and Dependency Order
version: 1.0.0
status: normative
---

# Package Manifest and Dependency Order

## 1. Purpose

This file declares the package inventory, dependency graph, and intended reading / implementation order.

## 2. Package inventory

| Order | File | Type | Depends on |
|---|---|---|---|
| 00 | `00_STYLE_GUIDE.md` | normative standard | none |
| 01 | `01_PACKAGE_MANIFEST.md` | manifest | `00_STYLE_GUIDE.md` |
| 02 | `02_SYSTEM_ORCHESTRATOR.md` | master algorithm | `03`-`11` |
| 03 | `03_INTAKE_AND_CLASSIFICATION.md` | subsystem algorithm | `00`, `01` |
| 04 | `04_PREPROCESSING_AND_ROUTING.md` | subsystem algorithm | `03` |
| 05 | `05_DOCUMENT_EXTRACTION_LANES.md` | subsystem algorithm | `04` |
| 06 | `06_MANUSCRIPT_DECIPHERING.md` | subsystem algorithm | `04`, `05` |
| 07 | `07_REDACTION_AND_DEIDENTIFICATION.md` | subsystem algorithm | `05`, `06` |
| 08 | `08_SEARCH_METADATA_AND_INDEXING.md` | subsystem algorithm | `05`, `06`, `07` |
| 09 | `09_SECURITY_COMPLIANCE_AND_AUDIT.md` | control algorithm | `03`-`08` |
| 10 | `10_DEPLOYMENT_AND_MODEL_SERVING.md` | platform algorithm | `02`-`09` |
| 11 | `11_VALIDATION_BENCHMARKING_AND_RELEASE.md` | assurance algorithm | `02`-`10` |
| 12 | `12_TEMPLATE_ALGORITHM.md` | reusable template | `00_STYLE_GUIDE.md` |
| 99 | `99_REFERENCE_MAP.md` | reference map | none |

## 3. Execution dependency view

```text
02_SYSTEM_ORCHESTRATOR
 ├── 03_INTAKE_AND_CLASSIFICATION
 ├── 04_PREPROCESSING_AND_ROUTING
 │    └── 05_DOCUMENT_EXTRACTION_LANES
 │         └── 06_MANUSCRIPT_DECIPHERING
 ├── 07_REDACTION_AND_DEIDENTIFICATION
 ├── 08_SEARCH_METADATA_AND_INDEXING
 ├── 09_SECURITY_COMPLIANCE_AND_AUDIT
 ├── 10_DEPLOYMENT_AND_MODEL_SERVING
 └── 11_VALIDATION_BENCHMARKING_AND_RELEASE
```

## 4. Governance dependency view

```text
00_STYLE_GUIDE
 ├── all algorithm files
 └── 12_TEMPLATE_ALGORITHM
99_REFERENCE_MAP
 └── all algorithm files
```

## 5. Package contract

Any future algorithm package that extends this one MUST:

1. preserve `00_STYLE_GUIDE.md`;
2. preserve `99_REFERENCE_MAP.md` or replace it with an equivalent controlled reference file;
3. update this manifest when files are added, removed, or renumbered;
4. keep the master orchestrator synchronized with subsystem changes.

## 6. Minimal author workflow

1. Copy `12_TEMPLATE_ALGORITHM.md`.
2. Assign a new `algorithm_id`.
3. Fill all mandatory sections.
4. Add references to `99_REFERENCE_MAP.md`.
5. Insert the file into this manifest.
6. If the algorithm changes execution flow, update `02_SYSTEM_ORCHESTRATOR.md`.

## 7. Review workflow

The package SHOULD be reviewed in this order:

1. Security / compliance review:
   - `03`, `07`, `09`, `10`
2. Data / archival workflow review:
   - `03`, `04`, `05`, `06`, `08`
3. Platform engineering review:
   - `02`, `04`, `05`, `10`, `11`
4. Governance sign-off:
   - `README.md`, `00_STYLE_GUIDE.md`, `01_PACKAGE_MANIFEST.md`

## 8. Package-level assumptions

- All model inference is intended to be **local or enclave-local**.
- Controlled-tier content is assumed to run in a **SecureLab-aligned boundary**.
- The package is a specification, not direct executable code.
- Thresholds and hardware classes are intentionally parameterized for later tuning.

## 9. Change log

- **1.0.0** — Initial manifest created.
