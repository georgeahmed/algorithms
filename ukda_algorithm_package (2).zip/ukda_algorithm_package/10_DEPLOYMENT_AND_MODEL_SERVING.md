---
algorithm_id: UKDA-ALG-010
title: Local Deployment and Model Serving
version: 1.0.0
status: normative
owner: Platform Engineering
depends_on:
  - 02_SYSTEM_ORCHESTRATOR.md
  - 09_SECURITY_COMPLIANCE_AND_AUDIT.md
last_updated: 2026-04-14
---

# ALGORITHM: Local Deployment and Model Serving

## 1. Purpose

Specify how the platform is deployed locally, how workers are assigned, and how models are governed for secure, efficient, high-throughput execution.

## 2. Scope

Covers control plane, CPU/GPU workers, storage services, model serving, promotion, and hardware tiering.

## 3. Inputs

- `JobQueue`
- `AccessTier`
- `WorkerRegistry`
- `ModelRegistry`
- `HardwarePolicy`

## 4. Outputs

- `SchedulingDecisions`
- `ModelInvocationPlan`
- `WorkerAssignments`
- `PromotionDecisions`

## 5. Dependencies

- local model-serving runtime (e.g., vLLM / equivalent);
- local OCR/HTR services;
- object store;
- canonical graph store;
- search cluster;
- audit store;
- model registry and benchmark gate.

## 6. Preconditions

- approved models are loaded locally;
- workers are labeled by trust tier and hardware class;
- storage services are reachable.

## 7. Postconditions

- each job is assigned to the correct hardware tier and security boundary;
- expensive reasoning is reserved for ambiguity-critical tasks;
- model promotion is benchmark-gated.

## 8. Invariants

1. Controlled jobs MUST NOT run on non-approved workers.
2. OCR and simple parsing SHOULD prefer cheaper workers.
3. Large VLM invocations MUST be rate-limited and justified by route.
4. No model upgrade may go live without benchmark and governance approval.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `CPU_POOL_SIZE` | OCR/metadata/rules workers |
| `GPU_POOL_A` | low-latency OCR/layout workers |
| `GPU_POOL_B` | complex parser / manuscript workers |
| `GPU_POOL_C` | flagship VLM workers |
| `USE_QWEN_THINKING_MODE_FOR_ADJUDICATION` | boolean |
| `USE_QWEN_NONTHINKING_FOR_STANDARD_TASKS` | boolean |
| `MODEL_PROMOTION_REQUIRES_BENCHMARK` | boolean |
| `FLAGSHIP_VLM_RATE_LIMIT` | cap on expensive calls |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-010 DeploymentAndModelServing
REQUIRE JobQueue, AccessTier, WorkerRegistry, ModelRegistry, HardwarePolicy
ENSURE SchedulingDecisions, ModelInvocationPlan, WorkerAssignments, PromotionDecisions

BEGIN
    FOR EACH job IN JobQueue DO
        ASSERT WorkerRegistry.has_tier_appropriate_workers(job.access_tier)

        IF job.task_type IN ["checksum", "malware_scan", "rules_redaction", "metadata_mapping", "bm25"] THEN
            ROUTE TO CPU_POOL
        ELSE IF job.task_type IN ["surya", "docling", "line_detection"] THEN
            ROUTE TO GPU_POOL_A
        ELSE IF job.task_type IN ["mineru", "paddleocr_vl", "kraken_training", "trocr", "htr_vt"] THEN
            ROUTE TO GPU_POOL_B
        ELSE IF job.task_type IN ["qwen3_vl_fallback", "qwen3_vl_adjudication"] THEN
            ROUTE TO GPU_POOL_C
        ELSE
            ROUTE TO CONSERVATIVE_DEFAULT_POOL
        END IF

        IF job.model_family = "Qwen3" THEN
            IF job.task_type IN ["adjudication", "compliance_reasoning", "ambiguity_resolution"] AND
               USE_QWEN_THINKING_MODE_FOR_ADJUDICATION = TRUE THEN
                SET job.inference_mode <- "THINKING"
            ELSE IF USE_QWEN_NONTHINKING_FOR_STANDARD_TASKS = TRUE THEN
                SET job.inference_mode <- "NON_THINKING"
            END IF
        END IF

        IF job.task_type IN ["qwen3_vl_fallback", "qwen3_vl_adjudication"] THEN
            ASSERT CurrentRate("FLAGSHIP_VLM") < FLAGSHIP_VLM_RATE_LIMIT
        END IF

        EMIT WorkerAssignment(job.id, selected_pool, job.inference_mode)
    END FOR

    RETURN {
        SchedulingDecisions,
        ModelInvocationPlan,
        WorkerAssignments,
        PromotionDecisions
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | low-cost task | CPU / cheaper worker |
| G2 | standard OCR/layout task | GPU Pool A |
| G3 | complex parser / handwriting models | GPU Pool B |
| G4 | flagship multimodal fallback/adjudication | GPU Pool C with rate limit |
| G5 | proposed model upgrade | benchmark gate required |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| worker pool exhausted | queue and backpressure; do not spill to lower-security pool |
| flagship VLM unavailable | reroute to alternate approved smaller model or queue |
| model registry mismatch | block invocation |
| promotion benchmark failure | keep current production model |

## 13. Audit Events

- `WORKER_ASSIGNED`
- `MODEL_MODE_SELECTED`
- `FLAGSHIP_VLM_RATE_LIMIT_HIT`
- `MODEL_PROMOTION_PROPOSED`
- `MODEL_PROMOTION_APPROVED`
- `MODEL_PROMOTION_REJECTED`

## 14. Human Escalation Conditions

- hardware-capacity planning;
- promotion of a new core parser or VLM;
- security exception for new worker classes;
- repeated queue pressure threatening service levels.

## 15. Security / Privacy / Compliance Notes

- vLLM documentation states the Qwen3-VL-235B flagship requires at least 8 GPUs with 80 GB each, which is why the architecture reserves flagship VLM use for the hardest pages instead of making it the default parser.  
  Reference: [R-VLLM-QWEN3-VL](99_REFERENCE_MAP.md#r-vllm-qwen3-vl)
- Qwen3 documentation describes controllable thinking/non-thinking modes, which supports selective use of expensive reasoning only when needed.  
  References: [R-QWEN3](99_REFERENCE_MAP.md#r-qwen3), [R-QWEN3-VLLM-DEPLOY](99_REFERENCE_MAP.md#r-qwen3-vllm-deploy)
- Local model serving is REQUIRED for controlled-tier workloads.

## 16. Metrics

- `gpu_utilization_by_pool`
- `queue_delay_by_task_type`
- `flagship_vlm_invocations_per_1000_pages`
- `promotion_pass_rate`
- `cost_per_page_by_lane`

## 17. References

- [R-VLLM-QWEN3-VL](99_REFERENCE_MAP.md#r-vllm-qwen3-vl)
- [R-QWEN3](99_REFERENCE_MAP.md#r-qwen3)
- [R-QWEN3-VLLM-DEPLOY](99_REFERENCE_MAP.md#r-qwen3-vllm-deploy)
