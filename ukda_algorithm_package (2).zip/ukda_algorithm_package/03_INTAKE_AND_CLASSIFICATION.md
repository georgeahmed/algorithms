---
algorithm_id: UKDA-ALG-003
title: Intake, Preservation, and Access Classification
version: 1.0.0
status: normative
owner: Ingest and Governance
depends_on:
  - 00_STYLE_GUIDE.md
  - 01_PACKAGE_MANIFEST.md
last_updated: 2026-04-14
---

# ALGORITHM: Intake, Preservation, and Access Classification

## 1. Purpose

Accept source documents safely, preserve originals immutably, capture governance metadata, and assign the correct access tier.

## 2. Scope

Covers all incoming files before any OCR, HTR, VLM, search indexing, or redaction.

## 3. Inputs

- `IntakePackage.source_files`
- `IntakePackage.depositor_metadata`
- `IntakePackage.contractual_terms`
- `IntakePackage.collection_context`
- `PolicyRegistry.access_rules`
- `RetentionPolicy`
- `MalwareScanner`
- `FormatIdentifier`

## 4. Outputs

- `IntakeResult.status`
- `IntakeResult.preserved_original`
- `IntakeResult.access_tier`
- `IntakeResult.job_manifest`
- `IntakeResult.dpia_flag`
- `IntakeResult.exception_reason` (if any)

## 5. Dependencies

- institutional policy and governance workflow;
- preservation storage;
- audit ledger;
- malware scanning and format-identification services.

## 6. Preconditions

- source package is received from an authenticated source or approved transfer route;
- storage and audit systems are available;
- policy registry is current.

## 7. Postconditions

- original file is preserved with checksum and immutable identifier;
- access tier is set to `OPEN`, `SAFEGUARDED`, `CONTROLLED`, or `PENDING_REVIEW`;
- no downstream processing starts for quarantined files.

## 8. Invariants

1. Original content MUST be preserved before transformation.
2. Intake MUST fail closed when policy or format cannot be established.
3. Controlled-tier assignment MUST dominate convenience or speed.
4. DPIA/governance flags MUST be emitted before risky processing begins.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `SUPPORTED_FORMATS` | approved input formats |
| `QUARANTINE_ON_UNKNOWN_FORMAT` | isolate unknown types |
| `ENABLE_ACTIVE_CONTENT_STRIPPING` | flatten and sanitize hostile formats |
| `DEFAULT_TIER_ON_UNCERTAINTY` | recommended value: `PENDING_REVIEW` or `CONTROLLED` |
| `DPIA_TRIGGER_ON_NEW_TECH` | boolean |
| `RETENTION_PROFILE` | retention and deletion schedule |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-003 IntakeAndClassification
REQUIRE IntakePackage, PolicyRegistry, RetentionPolicy
ENSURE IntakeResult

BEGIN
    CALL Audit("INTAKE_STARTED", IntakePackage.job_id)

    FOR EACH file IN IntakePackage.source_files DO
        ASSERT file.size > 0
        SET checksum <- CALL ComputeChecksum(file)
        SET file_format <- CALL IdentifyFormat(file)
        SET malware_status <- CALL ScanForMalware(file)

        IF malware_status = "INFECTED" THEN
            CALL Quarantine(file)
            CALL Audit("INTAKE_QUARANTINED_MALWARE", file.id)
            FAIL "MALWARE_DETECTED"
        END IF

        IF file_format NOT IN SUPPORTED_FORMATS THEN
            IF QUARANTINE_ON_UNKNOWN_FORMAT = TRUE THEN
                CALL Quarantine(file)
                CALL Audit("INTAKE_QUARANTINED_UNKNOWN_FORMAT", file.id)
                FAIL "UNSUPPORTED_FORMAT"
            END IF
        END IF

        SET preserved_original <- CALL PreserveImmutable(file, checksum, RetentionPolicy)
        CALL Audit("ORIGINAL_PRESERVED", file.id, checksum)
    END FOR

    SET depositor_terms <- CALL NormalizeDepositorTerms(IntakePackage.contractual_terms)
    SET sensitivity_evidence <- CALL DeriveSensitivityEvidence(
        IntakePackage.depositor_metadata,
        depositor_terms,
        IntakePackage.collection_context
    )

    SET access_tier <- CALL AssignAccessTier(sensitivity_evidence, PolicyRegistry)

    IF access_tier = "UNRESOLVED" THEN
        SET access_tier <- DEFAULT_TIER_ON_UNCERTAINTY
        CALL Audit("ACCESS_TIER_UNRESOLVED", IntakePackage.job_id, access_tier)
    END IF

    SET dpia_flag <- FALSE
    IF DPIA_TRIGGER_ON_NEW_TECH = TRUE AND
       IntakePackage.collection_context.contains_personal_or_sensitive_data = TRUE THEN
        SET dpia_flag <- TRUE
        CALL Audit("DPIA_TRIGGERED", IntakePackage.job_id)
    END IF

    SET job_manifest <- CALL CreateJobManifest(
        job_id = IntakePackage.job_id,
        source_checksums,
        file_formats,
        depositor_terms,
        access_tier,
        dpia_flag,
        retention_profile = RETENTION_PROFILE
    )

    CALL Audit("INTAKE_ACCEPTED", IntakePackage.job_id, access_tier)

    RETURN {
        status = "ACCEPTED",
        preserved_original,
        access_tier,
        job_manifest,
        dpia_flag
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | malware found | quarantine and stop |
| G2 | unsupported / ambiguous format | quarantine or fail closed |
| G3 | sensitivity unresolved | assign `PENDING_REVIEW` or `CONTROLLED` |
| G4 | personal data + new technology | emit DPIA flag |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| malware scan unavailable | fail closed; no processing |
| immutable store unavailable | retry; no downstream processing until stored |
| access tier ambiguous | governance review |
| missing depositor terms | apply conservative tier and request metadata remediation |

## 13. Audit Events

- `INTAKE_STARTED`
- `ORIGINAL_PRESERVED`
- `INTAKE_QUARANTINED_MALWARE`
- `INTAKE_QUARANTINED_UNKNOWN_FORMAT`
- `ACCESS_TIER_UNRESOLVED`
- `DPIA_TRIGGERED`
- `INTAKE_ACCEPTED`

## 14. Human Escalation Conditions

Escalate only when:

- legal / contractual restrictions are conflicting;
- access tier cannot be established automatically;
- collection contains novel or unusual sensitive content categories;
- DPIA/governance requires formal sign-off.

## 15. Security / Privacy / Compliance Notes

- UK Data Service uses open, safeguarded, and controlled access tiers.  
  Reference: [R-UKDS-ACCESS](99_REFERENCE_MAP.md#r-ukds-access)
- University of Essex requires UK GDPR / DPA 2018 compliance and states DPIAs are required for high-risk processing and where new technologies are involved.  
  References: [R-ESSEX-DP-POLICY](99_REFERENCE_MAP.md#r-essex-dp-policy), [R-ESSEX-DPIA](99_REFERENCE_MAP.md#r-essex-dpia)
- The University’s information-security policy provides the governing institutional context.  
  Reference: [R-ESSEX-INFOSEC](99_REFERENCE_MAP.md#r-essex-infosec)

## 16. Metrics

- `intake_accept_rate`
- `quarantine_rate`
- `tier_assignment_accuracy`
- `manifest_completeness_rate`
- `dpia_trigger_rate`

## 17. References

- [R-UKDS-ACCESS](99_REFERENCE_MAP.md#r-ukds-access)
- [R-ESSEX-DP-POLICY](99_REFERENCE_MAP.md#r-essex-dp-policy)
- [R-ESSEX-DPIA](99_REFERENCE_MAP.md#r-essex-dpia)
- [R-ESSEX-INFOSEC](99_REFERENCE_MAP.md#r-essex-infosec)
