---
algorithm_id: UKDA-ALG-008
title: Search, Metadata, and Indexing
version: 1.0.0
status: normative
owner: Discovery and Metadata Engineering
depends_on:
  - 05_DOCUMENT_EXTRACTION_LANES.md
  - 06_MANUSCRIPT_DECIPHERING.md
  - 07_REDACTION_AND_DEIDENTIFICATION.md
last_updated: 2026-04-14
---

# ALGORITHM: Search, Metadata, and Indexing

## 1. Purpose

Transform extracted and protected content into discovery-ready metadata and tier-separated search indexes.

## 2. Scope

Covers metadata creation, lexical indexing, semantic indexing, multimodal retrieval, and search snippet control.

## 3. Inputs

- `ProtectedCanonicalGraph`
- `AccessTier`
- `MetadataPolicy`
- `SearchPolicy`

## 4. Outputs

- `CollectionMetadata`
- `IndexArtifacts`
- `SnippetPolicy`
- `SearchAccessMap`

## 5. Dependencies

- DDI metadata mappings;
- lexical search engine;
- dense/sparse/multi-vector embedding services;
- multimodal embedding service.

## 6. Preconditions

- protected graph exists;
- redaction/release rules applied;
- index targets exist for each access tier.

## 7. Postconditions

- collection-level metadata exists;
- page/block-level searchable units are indexed;
- controlled and open discovery surfaces remain separated.

## 8. Invariants

1. Metadata and search MUST respect access tier.
2. Search snippets MUST NOT reveal restricted content.
3. Index artifacts MUST retain provenance to page/block coordinates.
4. Metadata SHOULD be DDI-aligned at collection level.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `USE_DDI_COLLECTION_METADATA` | DDI at collection/study level |
| `BM25_ENABLED` | exact / noisy lexical retrieval |
| `BGE_M3_ENABLED` | multilingual dense/sparse/multi-vector retrieval |
| `JINA_V4_ENABLED` | multimodal retrieval over visually rich pages |
| `INDEX_BY_TIER` | separate indexes for open/safeguarded/controlled |
| `SNIPPET_STRICT_MODE` | suppress sensitive snippets |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-008 SearchMetadataAndIndexing
REQUIRE ProtectedCanonicalGraph, AccessTier, MetadataPolicy, SearchPolicy
ENSURE CollectionMetadata, IndexArtifacts, SearchAccessMap

BEGIN
    CALL Audit("INDEXING_STARTED", ProtectedCanonicalGraph.document_id)

    SET collection_metadata <- CALL BuildDDIAlignedMetadata(
        ProtectedCanonicalGraph,
        MetadataPolicy
    )

    SET search_units <- CALL ChunkCanonicalGraph(
        ProtectedCanonicalGraph,
        preserve_coordinates = TRUE,
        preserve_section_boundaries = TRUE
    )

    IF BM25_ENABLED = TRUE THEN
        SET lexical_index <- CALL BuildLexicalIndex(search_units)
    END IF

    IF BGE_M3_ENABLED = TRUE THEN
        SET semantic_index <- CALL BuildBGEM3Index(search_units)
    END IF

    IF JINA_V4_ENABLED = TRUE THEN
        SET multimodal_index <- CALL BuildJinaV4Index(search_units)
    END IF

    SET snippet_policy <- CALL BuildSnippetPolicy(AccessTier, SearchPolicy)

    SET search_access_map <- CALL PublishIndexesByTier(
        lexical_index,
        semantic_index,
        multimodal_index,
        AccessTier,
        snippet_policy
    )

    CALL Audit("INDEXING_COMPLETED", search_access_map.summary)

    RETURN {
        CollectionMetadata = collection_metadata,
        IndexArtifacts = {
            lexical_index,
            semantic_index,
            multimodal_index
        },
        SnippetPolicy = snippet_policy,
        SearchAccessMap = search_access_map
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | open or release-cleared | public metadata/search allowed |
| G2 | safeguarded | restricted metadata/snippet view |
| G3 | controlled | enclave-only full text and page view |
| G4 | visually rich documents | include multimodal index |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| metadata mapping incomplete | preserve minimum viable catalogue record and flag |
| embedding service unavailable | publish lexical index first, retry semantic later |
| snippet leak risk | disable snippets for affected tier |
| coordinate loss in chunking | rebuild chunks from canonical graph |

## 13. Audit Events

- `INDEXING_STARTED`
- `DDI_METADATA_BUILT`
- `LEXICAL_INDEX_BUILT`
- `SEMANTIC_INDEX_BUILT`
- `MULTIMODAL_INDEX_BUILT`
- `SEARCH_PUBLISHED_BY_TIER`
- `INDEXING_COMPLETED`

## 14. Human Escalation Conditions

Human review is normally limited to:

- catalogue metadata exceptions for high-value collections;
- disputed access-tier publication rules;
- release-sensitive snippet complaints or governance checks.

## 15. Security / Privacy / Compliance Notes

- UK Data Service highlights DDI as a rich metadata standard widely used by social science archives.  
  Reference: [R-UKDS-METADATA-DDI](99_REFERENCE_MAP.md#r-ukds-metadata-ddi)
- BGE-M3 supports multilingual dense, sparse, and multi-vector retrieval.  
  Reference: [R-BGE-M3](99_REFERENCE_MAP.md#r-bge-m3)
- Jina Embeddings v4 is a multimodal multilingual embedding model aimed at visually rich document retrieval.  
  References: [R-JINA-V4](99_REFERENCE_MAP.md#r-jina-v4), [R-JINA-V4-MODEL](99_REFERENCE_MAP.md#r-jina-v4-model)
- Controlled-tier indexing MUST remain enclave-local and align with SecureLab practices.  
  Reference: [R-SECURELAB](99_REFERENCE_MAP.md#r-securelab)

## 16. Metrics

- `metadata_completeness_rate`
- `bm25_mrr`
- `semantic_ndcg_at_10`
- `multimodal_recall_at_k`
- `snippet_leak_incidents`
- `index_build_time`

## 17. References

- [R-UKDS-METADATA-DDI](99_REFERENCE_MAP.md#r-ukds-metadata-ddi)
- [R-BGE-M3](99_REFERENCE_MAP.md#r-bge-m3)
- [R-JINA-V4](99_REFERENCE_MAP.md#r-jina-v4)
- [R-JINA-V4-MODEL](99_REFERENCE_MAP.md#r-jina-v4-model)
- [R-SECURELAB](99_REFERENCE_MAP.md#r-securelab)
