---
document_id: UKDA-ALG-REFMAP-099
title: Reference Map
version: 1.0.0
status: normative
---

# Reference Map

This file centralizes the source references used across the package.

## R-RFC2119

**RFC 2119: Key words for use in RFCs to Indicate Requirement Levels**  
Why it matters: defines MUST / SHOULD / MAY language used by this package.  
URL: https://www.rfc-editor.org/rfc/rfc2119.html

## R-RFC8174

**RFC 8174: Ambiguity of Uppercase vs Lowercase in RFC 2119 Key Words**  
Why it matters: clarifies that the special meanings apply to uppercase forms.  
URL: https://www.rfc-editor.org/rfc/rfc8174.html

## R-COMMONMARK

**CommonMark Specification**  
Why it matters: plain-text Markdown portability baseline.  
URL: https://spec.commonmark.org/

## R-GFM

**GitHub Flavored Markdown Spec**  
Why it matters: practical rendering target for repository-hosted docs.  
URL: https://github.github.com/gfm/

## R-UKDS-ACCESS

**UK Data Service — Access conditions**  
Why it matters: defines open, safeguarded, and controlled access levels.  
URL: https://ukdataservice.ac.uk/find-data/access-conditions/

## R-SECURELAB

**UK Data Service — What is SecureLab?**  
Why it matters: defines controlled access for highly sensitive data and SecureLab role.  
URL: https://ukdataservice.ac.uk/help/secure-lab/what-is-securelab/

## R-SECURELAB-FAQ

**UK Data Service — SecureLab FAQs**  
Why it matters: confirms outputs can only leave SecureLab after disclosure checks.  
URL: https://ukdataservice.ac.uk/help/secure-lab/securelab-faqs/

## R-SAFE-OUTPUTS

**UKDS SecureLab user guide**  
Why it matters: operational reference for output requests and Statistical Disclosure Control.  
URL: https://ukdataservice.ac.uk/sa_user_guide/

## R-SECURELAB-TRAINING

**UK Data Service — Training requirements to access SecureLab**  
Why it matters: documents training on data security and statistical disclosure control.  
URL: https://ukdataservice.ac.uk/help/secure-lab/training-requirements/

## R-FIVE-SAFES

**UK Data Service — What is the Five Safes framework?**  
Why it matters: governing safety model for safe people, projects, settings, data, and outputs.  
URL: https://ukdataservice.ac.uk/help/secure-lab/what-is-the-five-safes-framework/

## R-ESSEX-DP-POLICY

**University of Essex — Data Protection Policy**  
Why it matters: institutional legal and policy baseline for personal-data processing and DPIA expectations.  
URL: https://www.essex.ac.uk/-/media/documents/directories/records-management/data-protection-policy.pdf

## R-ESSEX-DPIA

**University of Essex — Data Protection Impact Assessments**  
Why it matters: high-risk and new-technology processing governance trigger.  
URL: https://www.essex.ac.uk/staff/working-with-information-and-data/data-protection-impact-assessments

## R-ESSEX-INFOSEC

**University of Essex — Information Security Policy**  
Why it matters: institutional information-security governance baseline.  
URL: https://www.essex.ac.uk/-/media/documents/directories/records-management/information-security-policy.pdf

## R-ICO-SAFEGUARDS

**ICO — What are the appropriate safeguards?**  
Why it matters: research/archiving safeguards emphasizing minimisation, anonymisation, and pseudonymisation.  
URL: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/the-research-provisions/what-are-the-appropriate-safeguards/

## R-NCSC-AI

**NCSC — Guidelines for secure AI system development**  
Why it matters: secure design, deployment, and operation guidance for AI systems.  
URL: https://www.ncsc.gov.uk/collection/guidelines-secure-ai-system-development

## R-DOCLING

**Docling documentation**  
Why it matters: local document conversion and structured parsing toolkit.  
URL: https://docling-project.github.io/docling/

## R-SURYA

**Surya GitHub repository**  
Why it matters: local OCR, layout analysis, reading order, and table recognition in many languages.  
URL: https://github.com/datalab-to/surya

## R-MINERU

**MinerU GitHub repository**  
Why it matters: complex document parsing to Markdown/JSON.  
URL: https://github.com/opendatalab/mineru

## R-QWEN3-VL

**Qwen3-VL GitHub repository**  
Why it matters: multimodal fallback / adjudication with strong OCR and document parsing claims.  
URL: https://github.com/QwenLM/Qwen3-VL

## R-QWEN3

**Qwen3 GitHub repository**  
Why it matters: local text reasoning models with thinking / non-thinking modes.  
URL: https://github.com/QwenLM/qwen3

## R-QWEN3-VLLM-DEPLOY

**Qwen3 deployment with vLLM**  
Why it matters: official deployment notes for thinking/non-thinking control.  
URL: https://github.com/QwenLM/Qwen3/blob/main/docs/source/deployment/vllm.md

## R-VLLM-QWEN3-VL

**vLLM recipe for Qwen3-VL**  
Why it matters: hardware sizing for the flagship Qwen3-VL model.  
URL: https://docs.vllm.ai/projects/recipes/en/latest/Qwen/Qwen3-VL.html

## R-PADDLEOCR-VL

**PaddleOCR GitHub repository**  
Why it matters: optional complex-document parser challenger, with OmniDocBench claims and real-world robustness claims by maintainers.  
URL: https://github.com/PaddlePaddle/PaddleOCR

## R-OMNIDOCBENCH

**OmniDocBench GitHub repository**  
Why it matters: document parsing evaluation dimensions and metrics.  
URL: https://github.com/opendatalab/OmniDocBench

## R-DOCRES

**DocRes official repository / paper**  
Why it matters: unified document image restoration for dewarping, deshadowing, appearance enhancement, deblurring, and binarization.  
URL: https://github.com/ZZZHANG-jx/DocRes

## R-KRAKEN

**Kraken documentation**  
Why it matters: trainable OCR/HTR optimized for historical and non-Latin script material.  
URL: https://kraken.re/6.0.0/index.html

## R-KRAKEN-TRAIN

**Kraken training documentation**  
Why it matters: trainable segmentation and recognition for collection-specific adaptation.  
URL: https://kraken.re/6.0.0/training.html

## R-ESCRIPTORIUM

**eScriptorium documentation**  
Why it matters: collaborative transcription environment using Kraken as engine.  
URL: https://escriptorium.readthedocs.io/

## R-TROCR

**TrOCR official Microsoft Research page**  
Why it matters: transformer OCR model usable for handwritten recognition.  
URL: https://www.microsoft.com/en-us/research/publication/trocr-transformer-based-optical-character-recognition-with-pre-trained-models/

## R-HTR-VT

**HTR-VT official implementation**  
Why it matters: modern ViT-based HTR baseline.  
URL: https://github.com/yutingli0606/htr-vt

## R-LLM-HTR-BENCH

**Benchmarking Large Language Models for Handwritten Text Recognition**  
Why it matters: supports the recommendation to combine specialist HTR models with VLM adjudication rather than rely on a single MLLM.  
URL: https://arxiv.org/abs/2503.15195

## R-AUGMENTED-CONSENSUS

**Improving MLLM Historical Record Extraction with Test-Time Image Augmentation**  
Why it matters: supports optional multi-view consensus on noisy historical documents.  
URL: https://arxiv.org/html/2509.09722v1

## R-PRESIDIO

**Microsoft Presidio documentation**  
Why it matters: text/image/structured-data detection and anonymization/redaction toolkit.  
URL: https://microsoft.github.io/presidio/

## R-PRESIDIO-IMAGE

**Presidio Image Redactor**  
Why it matters: image redaction support and caveats.  
URL: https://microsoft.github.io/presidio/image-redactor/

## R-GLINER

**GLiNER GitHub repository**  
Why it matters: lightweight local entity extraction for redaction pipelines.  
URL: https://github.com/urchade/GLiNER

## R-UKDS-METADATA-DDI

**UK Data Service — Metadata**  
Why it matters: DDI relevance for archive metadata practice.  
URL: https://ukdataservice.ac.uk/learning-hub/research-data-management/document-your-data/metadata/

## R-BGE-M3

**M3-Embedding paper (BGE-M3)**  
Why it matters: multilingual dense/sparse/multi-vector retrieval model.  
URL: https://aclanthology.org/2024.findings-acl.137/

## R-JINA-V4

**Jina Embeddings landing page**  
Why it matters: multimodal multilingual retrieval positioning for jina-embeddings-v4.  
URL: https://jina.ai/embeddings/

## R-JINA-V4-MODEL

**jina-embeddings-v4 model page**  
Why it matters: intended usage for complex document retrieval.  
URL: https://huggingface.co/jinaai/jina-embeddings-v4

## R-UKDA-CORETRUSTSEAL

**UK Data Archive recertifies under the CoreTrustSeal**  
Why it matters: current trust-repository accreditation context.  
URL: https://ukdataservice.ac.uk/2025/07/16/coretrustseal/

## R-UKDS-DEA

**UK Data Service accredited for the provision and preparation of data under the Digital Economy Act**  
Why it matters: current processor accreditation context.  
URL: https://ukdataservice.ac.uk/2025/04/21/digital-economy-act/

## R-UKDS-FORMATS

**UK Data Service — Recommended formats**  
Why it matters: archival preservation context for preferred formats.  
URL: https://ukdataservice.ac.uk/learning-hub/research-data-management/format-your-data/recommended-formats/
