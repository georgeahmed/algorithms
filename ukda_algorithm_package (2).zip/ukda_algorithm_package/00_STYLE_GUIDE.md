---
document_id: UKDA-ALG-STYLE-000
title: Algorithm Writing Standard for Markdown Packages
version: 1.0.0
status: normative
---

# Algorithm Writing Standard for Markdown Packages

This file defines the **mandatory writing standard** for all future algorithm files in this package.

## 1. Normative language

The uppercase terms **MUST**, **MUST NOT**, **REQUIRED**, **SHALL**, **SHALL NOT**, **SHOULD**, **SHOULD NOT**, **RECOMMENDED**, **MAY**, and **OPTIONAL** MUST be interpreted according to RFC 2119 and RFC 8174.  
References: [R-RFC2119](99_REFERENCE_MAP.md#r-rfc2119), [R-RFC8174](99_REFERENCE_MAP.md#r-rfc8174)

## 2. Markdown standard

All files SHOULD remain compatible with **CommonMark** and **GitHub Flavored Markdown (GFM)** to maximize portability across repositories, code-review tools, and static documentation systems.  
References: [R-COMMONMARK](99_REFERENCE_MAP.md#r-commonmark), [R-GFM](99_REFERENCE_MAP.md#r-gfm)

## 3. One-file-one-algorithm rule

Each `.md` algorithm file MUST describe exactly one of the following:

- one end-to-end orchestrator; or
- one subsystem algorithm; or
- one template / style specification.

Do not hide multiple independent algorithms in a single file.

## 4. Mandatory section order

Every operational algorithm file MUST contain these sections in this order:

1. `Purpose`
2. `Scope`
3. `Inputs`
4. `Outputs`
5. `Dependencies`
6. `Preconditions`
7. `Postconditions`
8. `Invariants`
9. `Configuration Parameters`
10. `Procedure` (pseudocode)
11. `Decision Gates`
12. `Failure Modes and Recovery`
13. `Audit Events`
14. `Human Escalation Conditions`
15. `Security / Privacy / Compliance Notes`
16. `Metrics`
17. `References`

## 5. Front matter requirements

Each file MUST start with YAML front matter containing:

```yaml
---
algorithm_id: UKDA-ALG-XXX
title: <clear title>
version: <semantic version>
status: draft|normative|informative
owner: <team or function>
depends_on:
  - <algorithm file name>
last_updated: YYYY-MM-DD
---
```

## 6. Pseudocode grammar

Use the following verbs consistently:

| Keyword | Meaning |
|---|---|
| `REQUIRE` | Mandatory input or prerequisite |
| `ENSURE` | Guaranteed output or postcondition |
| `ASSERT` | Hard validation that stops execution on failure |
| `SET` | Assign a value |
| `CALL` | Invoke another algorithm or service |
| `FOR EACH` | Deterministic iteration |
| `PARALLEL FOR EACH` | Concurrent processing allowed |
| `IF / ELSE IF / ELSE` | Branching |
| `ROUTE TO` | Task routing |
| `ESCALATE` | Human review or governance intervention |
| `EMIT` | Produce output artifact / event |
| `AUDIT` | Persist audit record |
| `RETURN` | End algorithm with outputs |
| `FAIL` | Terminal failure state |

### 6.1 Example style

```text
ALGORITHM UKDA-ALG-999 Example
REQUIRE InputBundle
ENSURE OutputBundle

BEGIN
    ASSERT InputBundle.integrity = TRUE
    CALL Audit("EXAMPLE_STARTED", InputBundle.id)
    FOR EACH item IN InputBundle.items DO
        IF item.risk_score >= HIGH_RISK_THRESHOLD THEN
            ESCALATE item TO HumanReviewQueue
        ELSE
            EMIT ProcessedItem(item)
        END IF
    END FOR
    RETURN OutputBundle
END
```

## 7. Algorithm quality rules

Every algorithm file MUST satisfy the following:

1. **Deterministic entry and exit.** Inputs and outputs MUST be explicit.
2. **No hidden side effects.** Audit writes, redactions, model calls, and storage writes MUST be named.
3. **Explicit thresholds.** Confidence and routing thresholds MUST be configuration parameters, not buried in prose.
4. **Visible failure states.** Every irreversible or hazardous failure MUST be documented.
5. **Versionable behavior.** Any model, prompt, schema, or policy dependency MUST be versioned.
6. **Access-tier awareness.** If data sensitivity matters, the algorithm MUST state how open / safeguarded / controlled tiers are separated.
7. **Human review boundaries.** A file MUST state exactly when humans are allowed to intervene.
8. **Provenance everywhere.** Downstream outputs MUST preserve source-file hash, page/line coordinates when available, model version, and confidence.
9. **No silent normalization for historical manuscripts.** Diplomatic transcription MUST preserve ambiguity explicitly.

## 8. Recommended file naming convention

Use:

```text
NN_<UPPERCASE_OR_CLEAR_SNAKE_CASE>.md
```

In this package, a simpler readable numeric pattern is already used:

```text
02_SYSTEM_ORCHESTRATOR.md
03_INTAKE_AND_CLASSIFICATION.md
...
```

Future files SHOULD continue that convention.

## 9. Writing style rules

### 9.1 Write pseudocode first
Start with the executable logic. Explanatory prose comes afterwards.

### 9.2 Prefer imperative verbs
Use language such as:

- “Validate”
- “Route”
- “Fuse”
- “Redact”
- “Escalate”
- “Persist”
- “Release”

Avoid vague wording such as “handle,” “work with,” or “deal with.”

### 9.3 Separate normative and explanatory content
Normative requirements SHOULD be in bullet lists or tables under clearly named sections.
Explanatory background SHOULD be brief and secondary.

### 9.4 Avoid prose-only architecture
If a reader cannot see entry conditions, branching rules, and outputs in under 30 seconds, the algorithm is under-specified.

## 10. Security writing rules

Any file touching sensitive or controlled data MUST state:

- data tier affected;
- storage boundary;
- model boundary;
- network egress policy;
- encryption expectation;
- audit expectation;
- release policy.

Files involving AI MUST also state:

- model family;
- serving boundary;
- fallback path;
- prompt / schema control;
- confidence handling;
- hallucination containment strategy.

## 11. Compliance writing rules

If personal, confidential, or controlled data may appear, the algorithm MUST include:

- lawful basis / governance trigger where relevant;
- DPIA trigger or reference;
- minimisation expectation;
- retention note;
- output release rule;
- reviewer responsibility when escalation occurs.

Relevant context for this package comes from UK Data Service access-tier practice, SecureLab, the Five Safes, University of Essex data-protection and information-security policy, and ICO research safeguards.  
References: [R-UKDS-ACCESS](99_REFERENCE_MAP.md#r-ukds-access), [R-SECURELAB](99_REFERENCE_MAP.md#r-securelab), [R-FIVE-SAFES](99_REFERENCE_MAP.md#r-five-safes), [R-ESSEX-DP-POLICY](99_REFERENCE_MAP.md#r-essex-dp-policy), [R-ESSEX-INFOSEC](99_REFERENCE_MAP.md#r-essex-infosec), [R-ICO-SAFEGUARDS](99_REFERENCE_MAP.md#r-ico-safeguards)

## 12. Citation rules inside package files

Use one of these two styles:

### Style A — local reference map
```markdown
Reference: [R-QWEN3-VL](99_REFERENCE_MAP.md#r-qwen3-vl)
```

### Style B — grouped list
```markdown
References:
- [R-DOCLING](99_REFERENCE_MAP.md#r-docling)
- [R-SURYA](99_REFERENCE_MAP.md#r-surya)
```

Do not paste unmanaged raw links all through the algorithm body unless strictly necessary.

When algorithm packages are intended for preservation or repository deposit, prefer plain-text Markdown and bundle them as immutable release artifacts alongside a zip package. For broader archival context on preferred preservation formats, see [R-UKDS-FORMATS](99_REFERENCE_MAP.md#r-ukds-formats).

## 13. Change control rules

Any future revision MUST increment version when one of the following changes:

- routing logic;
- security boundary;
- human escalation rule;
- model family;
- threshold default;
- output schema;
- compliance control.

## 14. The best-practice package pattern

For your future requests, the recommended package structure is:

1. `README.md`
2. `00_STYLE_GUIDE.md`
3. `01_PACKAGE_MANIFEST.md`
4. one file per operational algorithm
5. `12_TEMPLATE_ALGORITHM.md`
6. `99_REFERENCE_MAP.md`

This keeps the package readable, reviewable, and scalable.
