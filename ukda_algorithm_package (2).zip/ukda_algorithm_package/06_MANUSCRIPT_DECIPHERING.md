---
algorithm_id: UKDA-ALG-006
title: Manuscript Deciphering for Degraded and Near-Illegible Handwriting
version: 1.0.0
status: normative
owner: Manuscript AI / Special Collections
depends_on:
  - 04_PREPROCESSING_AND_ROUTING.md
  - 05_DOCUMENT_EXTRACTION_LANES.md
last_updated: 2026-04-14
---

# ALGORITHM: Manuscript Deciphering for Degraded and Near-Illegible Handwriting

## 1. Purpose

Provide the strongest practical local workflow for difficult handwritten manuscripts, especially degraded, noisy, faint, warped, or near-illegible pages that challenge human readers.

## 2. Scope

Applies to pages or collections where:

- handwriting likelihood is high;
- ordinary OCR/parsing underperforms;
- diplomatic transcription quality matters;
- ambiguity must remain explicit.

## 3. Inputs

- `PrepResult.PageBundle` with `MANUSCRIPT_LANE` pages
- `ExtractionResult` placeholders or low-confidence outputs
- `HTRModelRegistry`
- `LanguageModelRegistry`
- `ThresholdRegistry.manuscripts`

## 4. Outputs

- `ManuscriptGraph`
- `DiplomaticTranscription`
- `NormalizedTranscription`
- `AlternativeReadings`
- `LineConfidenceScores`
- `EscalationQueue`

## 5. Dependencies

- `Kraken` / `eScriptorium`
- `TrOCR`
- `HTR-VT`
- `Qwen3-VL`
- line / region segmentation
- optional restoration augmentation pipeline

## 6. Preconditions

- manuscript page identified by routing or downstream failure;
- handwriting-capable models available for the script/language family;
- collection-specific fine-tuned model available when onboarding has occurred.

## 7. Postconditions

- each line has at least one transcription hypothesis;
- diplomatic and normalized outputs are separated;
- unresolved ambiguity is preserved;
- only unresolved lines/pages go to human review.

## 8. Invariants

1. Diplomatic transcription MUST NOT silently normalize uncertain graphemes.
2. Multiple recognizers MUST be used for hard pages.
3. Contextual adjudication MUST NOT erase underlying alternative readings.
4. The preserved original and restored variants MUST remain linked.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `ENABLE_COLLECTION_FINE_TUNE` | use collection-adapted Kraken/eScriptorium model |
| `ENABLE_AUGMENTED_HYPOTHESES` | generate augmented image views for consensus |
| `MAX_AUGMENTED_VIEWS` | limit on alternate restored variants |
| `LINE_ACCEPT_THRESHOLD` | auto-accept confidence per line |
| `PAGE_ACCEPT_THRESHOLD` | auto-accept confidence per page |
| `DIVERGENCE_THRESHOLD` | disagreement threshold triggering adjudication |
| `QWEN_ADJUDICATION_ENABLED` | use Qwen3-VL as arbiter |
| `HUMAN_REVIEW_THRESHOLD` | below this line confidence, escalate |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-006 ManuscriptDeciphering
REQUIRE PageBundle, HTRModelRegistry, ThresholdRegistry
ENSURE ManuscriptGraph, DiplomaticTranscription, NormalizedTranscription, AlternativeReadings

BEGIN
    CALL Audit("MANUSCRIPT_LANE_STARTED", count(manuscript_pages))

    PARALLEL FOR EACH manuscript_page IN manuscript_pages DO
        SET base_image <- manuscript_page.restored_page

        SET line_regions <- CALL SegmentLinesAndRegions(base_image)

        IF ENABLE_AUGMENTED_HYPOTHESES = TRUE THEN
            SET views <- CALL SelectAugmentedViews(base_image, MAX_AUGMENTED_VIEWS)
        ELSE
            SET views <- [base_image]
        END IF

        FOR EACH line IN line_regions DO
            SET hypotheses <- []

            FOR EACH view IN views DO
                APPEND hypotheses <- CALL KrakenRecognize(line, view)
                APPEND hypotheses <- CALL TrOCRRecognize(line, view)
                APPEND hypotheses <- CALL HTRVTRecognize(line, view)
            END FOR

            SET consensus <- CALL BuildConsensus(
                hypotheses,
                preserve_alternatives = TRUE,
                preserve_uncertainty = TRUE
            )

            IF consensus.divergence >= DIVERGENCE_THRESHOLD AND
               QWEN_ADJUDICATION_ENABLED = TRUE THEN
                SET adjudicated <- CALL Qwen3VLAdjudicate(
                    line_image = line,
                    page_context = manuscript_page,
                    hypotheses = hypotheses,
                    policy = "DIPLOMATIC_NO_SILENT_NORMALIZATION"
                )
                SET consensus <- CALL MergeConsensusAndAdjudication(consensus, adjudicated)
            END IF

            SET diplomatic_line <- CALL RenderDiplomatic(consensus)
            SET normalized_line <- CALL RenderNormalized(consensus)
            SET line_confidence <- CALL ScoreLineConfidence(consensus)

            IF line_confidence < HUMAN_REVIEW_THRESHOLD THEN
                ESCALATE line TO HumanManuscriptReviewQueue
            END IF

            EMIT LineRecord(
                page_id = manuscript_page.page_id,
                line_id = line.id,
                diplomatic = diplomatic_line,
                normalized = normalized_line,
                alternatives = consensus.alternatives,
                confidence = line_confidence,
                coordinates = line.coordinates
            )
        END FOR

        SET page_confidence <- CALL AggregatePageConfidence(LineRecords for manuscript_page)

        IF page_confidence < PAGE_ACCEPT_THRESHOLD THEN
            SET manuscript_page.flags += "LOW_CONFIDENCE_PAGE"
        END IF
    END FOR

    SET ManuscriptGraph <- CALL MergeLineRecords(LineRecordSet)
    CALL Audit("MANUSCRIPT_LANE_COMPLETED", summary(ManuscriptGraph))

    RETURN {
        ManuscriptGraph,
        DiplomaticTranscription,
        NormalizedTranscription,
        AlternativeReadings,
        LineConfidenceScores,
        EscalationQueue
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | handwriting route selected | specialist HTR ensemble |
| G2 | severe degradation | augmented views + restoration variants |
| G3 | model disagreement high | Qwen3-VL adjudication |
| G4 | low line confidence | human line review |
| G5 | low page confidence but high-value content | page-level human validation |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| line segmentation poor | retrain/fine-tune segmenter; use manual baseline correction only for gold-set creation |
| all recognizers fail | keep image-only placeholder; escalate |
| Qwen adjudication conflicts with consensus | preserve both and mark unresolved |
| script drift / unseen handwriting style | trigger onboarding/fine-tune workflow |

## 13. Audit Events

- `MANUSCRIPT_LANE_STARTED`
- `LINE_SEGMENTED`
- `HTR_HYPOTHESES_CREATED`
- `QWEN_ADJUDICATION_USED`
- `LINE_ESCALATED`
- `MANUSCRIPT_LANE_COMPLETED`

## 14. Human Escalation Conditions

Human review is allowed only for:

1. onboarding a new script/hand/collection;
2. unresolved low-confidence lines;
3. pages selected for gold-set validation;
4. release-critical passages where uncertainty remains material.

## 15. Security / Privacy / Compliance Notes

- Kraken is optimized for historical and non-Latin-script material and supports trainable segmentation and recognition.  
  References: [R-KRAKEN](99_REFERENCE_MAP.md#r-kraken), [R-KRAKEN-TRAIN](99_REFERENCE_MAP.md#r-kraken-train)
- eScriptorium uses Kraken as its segmentation/transcription engine and supports iterative correction/fine-tuning workflows.  
  Reference: [R-ESCRIPTORIUM](99_REFERENCE_MAP.md#r-escriptorium)
- TrOCR is an end-to-end transformer OCR model that can be fine-tuned on handwritten data.  
  Reference: [R-TROCR](99_REFERENCE_MAP.md#r-trocr)
- HTR-VT is an official Vision Transformer baseline for handwritten text recognition.  
  Reference: [R-HTR-VT](99_REFERENCE_MAP.md#r-htr-vt)
- Recent benchmarking found no consistent overall advantage of MLLMs over specialist HTR systems and only limited autonomous self-correction, which supports the ensemble design here rather than a single-model design.  
  Reference: [R-LLM-HTR-BENCH](99_REFERENCE_MAP.md#r-llm-htr-bench)
- Optional augmented-hypothesis consensus is justified by recent evidence that image-augmentation plus consensus fusion can improve extraction stability on noisy historical documents.  
  Reference: [R-AUGMENTED-CONSENSUS](99_REFERENCE_MAP.md#r-augmented-consensus)

## 16. Metrics

- `CER`
- `WER`
- `line_accept_rate`
- `page_accept_rate`
- `human_review_share`
- `alternative_reading_density`
- `confidence_calibration_error`

## 17. References

- [R-KRAKEN](99_REFERENCE_MAP.md#r-kraken)
- [R-KRAKEN-TRAIN](99_REFERENCE_MAP.md#r-kraken-train)
- [R-ESCRIPTORIUM](99_REFERENCE_MAP.md#r-escriptorium)
- [R-TROCR](99_REFERENCE_MAP.md#r-trocr)
- [R-HTR-VT](99_REFERENCE_MAP.md#r-htr-vt)
- [R-LLM-HTR-BENCH](99_REFERENCE_MAP.md#r-llm-htr-bench)
- [R-AUGMENTED-CONSENSUS](99_REFERENCE_MAP.md#r-augmented-consensus)
