---
algorithm_id: UKDA-ALG-009
title: Security, Compliance, and Audit Control Plane
version: 1.0.0
status: normative
owner: Security and Governance
depends_on:
  - 03_INTAKE_AND_CLASSIFICATION.md
  - 07_REDACTION_AND_DEIDENTIFICATION.md
  - 08_SEARCH_METADATA_AND_INDEXING.md
last_updated: 2026-04-14
---

# ALGORITHM: Security, Compliance, and Audit Control Plane

## 1. Purpose

Enforce security, privacy, governance, and audit controls across all stages of processing.

## 2. Scope

Applies to all jobs, all access tiers, all models, all derivatives, and all release actions.

## 3. Inputs

- all subsystem outputs;
- `AccessTier`;
- `ModelRegistry`;
- `PromptRegistry`;
- `SecretsPolicy`;
- `ReleaseRules`;
- `IncidentPolicy`.

## 4. Outputs

- `AuditLedgerEntries`
- `ComplianceFlags`
- `PolicyDecisions`
- `ReleasePermissions`
- `IncidentTickets` (if any)

## 5. Dependencies

- audit ledger;
- encryption and key-management services;
- identity and access management;
- model/prompt registry;
- release workflow / output checking;
- incident-response workflow.

## 6. Preconditions

- identity and policy systems online;
- job has an assigned tier;
- processing services authenticated.

## 7. Postconditions

- every sensitive action is auditable;
- every model/prompt invocation is attributable;
- every release action is policy checked;
- any incident condition is ticketed.

## 8. Invariants

1. Controlled data MUST remain in a controlled boundary.
2. Model/network egress MUST be denied by default.
3. Secrets MUST NOT be exposed to model prompts.
4. Release MUST fail closed when output controls are unavailable.
5. Audit logs MUST be immutable or append-only.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `ENCRYPT_AT_REST` | required for all tiers |
| `ENCRYPT_IN_TRANSIT` | required for all tiers |
| `ALLOW_MODEL_NETWORK_EGRESS` | recommended value `FALSE` |
| `PROMPT_REGISTRY_ENFORCED` | boolean |
| `SAFE_OUTPUT_REVIEW_REQUIRED_FOR_CONTROLLED` | boolean |
| `SESSION_MFA_REQUIRED` | boolean |
| `APPEND_ONLY_AUDIT` | boolean |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-009 SecurityComplianceAndAudit
REQUIRE JobArtifacts, AccessTier, ModelRegistry, PromptRegistry, ReleaseRules
ENSURE AuditLedgerEntries, ComplianceFlags, PolicyDecisions, ReleasePermissions

BEGIN
    ASSERT ENCRYPT_AT_REST = TRUE
    ASSERT ENCRYPT_IN_TRANSIT = TRUE
    ASSERT APPEND_ONLY_AUDIT = TRUE

    CALL Audit("SECURITY_CONTROL_EVALUATION_STARTED", JobArtifacts.job_id)

    CALL VerifyTierBoundary(JobArtifacts, AccessTier)
    CALL VerifyApprovedModelsOnly(JobArtifacts.model_calls, ModelRegistry)
    CALL VerifyApprovedPromptsOnly(JobArtifacts.prompt_calls, PromptRegistry)
    CALL VerifyNoUnauthorizedNetworkEgress(JobArtifacts.runtime_sessions)
    CALL VerifySecretsIsolation(JobArtifacts.runtime_sessions)
    CALL VerifyRoleBasedAccess(JobArtifacts.user_context)
    CALL VerifyMFAIfRequired(JobArtifacts.user_context, SESSION_MFA_REQUIRED)

    IF AccessTier = "CONTROLLED" THEN
        ASSERT SAFE_OUTPUT_REVIEW_REQUIRED_FOR_CONTROLLED = TRUE
        CALL VerifyControlledBoundaryControls(JobArtifacts)
    END IF

    SET compliance_flags <- CALL EvaluateComplianceFlags(JobArtifacts)

    IF compliance_flags.contains("INCIDENT") THEN
        SET incident_ticket <- CALL OpenIncident(JobArtifacts, compliance_flags)
        CALL Audit("INCIDENT_OPENED", incident_ticket.id)
    END IF

    SET release_permissions <- CALL DecideReleasePermissions(AccessTier, ReleaseRules, compliance_flags)

    CALL Audit("SECURITY_CONTROL_EVALUATION_COMPLETED", release_permissions.status)

    RETURN {
        AuditLedgerEntries,
        ComplianceFlags = compliance_flags,
        PolicyDecisions,
        ReleasePermissions = release_permissions,
        IncidentTickets = incident_ticket
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | unapproved model/prompt | block job or fail release |
| G2 | unauthorized network egress | terminate session / incident |
| G3 | controlled-tier output requested | safe-output review mandatory |
| G4 | policy violation detected | fail closed and ticket |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| IAM unavailable | pause job; no release |
| audit store unavailable | fail closed for controlled jobs |
| prompt registry mismatch | block inference and require approval |
| output checking unavailable | queue release but do not export |

## 13. Audit Events

- `SECURITY_CONTROL_EVALUATION_STARTED`
- `MODEL_REGISTRY_VALIDATED`
- `PROMPT_REGISTRY_VALIDATED`
- `BOUNDARY_VERIFIED`
- `RELEASE_PERMISSION_DECIDED`
- `INCIDENT_OPENED`
- `SECURITY_CONTROL_EVALUATION_COMPLETED`

## 14. Human Escalation Conditions

- policy conflicts or exceptions;
- output release of controlled material;
- incident handling;
- major model/prompt promotion decisions.

## 15. Security / Privacy / Compliance Notes

- NCSC’s secure AI system development guidance frames security across design, development, deployment, and operation, which matches this control-plane approach.  
  Reference: [R-NCSC-AI](99_REFERENCE_MAP.md#r-ncsc-ai)
- SecureLab provides the controlled access model for highly sensitive data and uses staff-led disclosure control for outputs.  
  References: [R-SECURELAB](99_REFERENCE_MAP.md#r-securelab), [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs), [R-SECURELAB-FAQ](99_REFERENCE_MAP.md#r-securelab-faq)
- University of Essex information security and data-protection policy form the institutional compliance baseline.  
  References: [R-ESSEX-INFOSEC](99_REFERENCE_MAP.md#r-essex-infosec), [R-ESSEX-DP-POLICY](99_REFERENCE_MAP.md#r-essex-dp-policy)
- The Five Safes framework is the correct governing concept for safe people, projects, settings, data, and outputs.  
  Reference: [R-FIVE-SAFES](99_REFERENCE_MAP.md#r-five-safes)
- UK Data Archive CoreTrustSeal recertification and UK Data Service Digital Economy Act accreditation are relevant institutional trust and processor-governance context for this platform.  
  References: [R-UKDA-CORETRUSTSEAL](99_REFERENCE_MAP.md#r-ukda-coretrustseal), [R-UKDS-DEA](99_REFERENCE_MAP.md#r-ukds-dea)

## 16. Metrics

- `policy_violation_rate`
- `unauthorized_egress_attempts`
- `audit_completeness_rate`
- `release_hold_rate`
- `incident_rate`

## 17. References

- [R-NCSC-AI](99_REFERENCE_MAP.md#r-ncsc-ai)
- [R-SECURELAB](99_REFERENCE_MAP.md#r-securelab)
- [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs)
- [R-SECURELAB-FAQ](99_REFERENCE_MAP.md#r-securelab-faq)
- [R-ESSEX-INFOSEC](99_REFERENCE_MAP.md#r-essex-infosec)
- [R-ESSEX-DP-POLICY](99_REFERENCE_MAP.md#r-essex-dp-policy)
- [R-FIVE-SAFES](99_REFERENCE_MAP.md#r-five-safes)
