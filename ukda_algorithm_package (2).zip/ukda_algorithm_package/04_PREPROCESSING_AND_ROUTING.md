---
algorithm_id: UKDA-ALG-004
title: Preprocessing, Restoration, and Routing
version: 1.0.0
status: normative
owner: Document AI Pipeline
depends_on:
  - 03_INTAKE_AND_CLASSIFICATION.md
last_updated: 2026-04-14
---

# ALGORITHM: Preprocessing, Restoration, and Routing

## 1. Purpose

Convert preserved documents into page-level processing units, restore degraded images, score quality/complexity, and route pages to the cheapest correct extraction lane.

## 2. Scope

Applies to all accepted documents before OCR/HTR/VLM parsing.

## 3. Inputs

- `IntakeResult.preserved_original`
- `IntakeResult.access_tier`
- `ThresholdRegistry.routing`
- `RestorationModels`
- `PageClassifierModels`

## 4. Outputs

- `PageBundle`
- `RoutingPlan`
- `RestoredImages`
- `PageScores`
- `Flags`

## 5. Dependencies

- rasteriser / PDF renderer;
- document restoration engine;
- language / script detector;
- layout complexity scorer;
- handwriting detector.

## 6. Preconditions

- original file preserved;
- access tier assigned;
- renderer sandbox available.

## 7. Postconditions

- every page has an image representation or equivalent native-text representation;
- every page has route metadata;
- every page is tagged with quality and complexity scores.

## 8. Invariants

1. Rendering MUST occur in a sandboxed environment.
2. Page routing MUST be explainable by stored scores.
3. Restoration MUST preserve the original separately; it MUST NOT overwrite preserved originals.
4. Handwriting suspicion MUST trigger manuscript consideration before generic fallback.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `NATIVE_TEXT_MIN_RATIO` | minimum embedded-text coverage to prefer native-text route |
| `QUALITY_RESTORE_THRESHOLD` | page quality below which restoration is mandatory |
| `LAYOUT_COMPLEXITY_THRESHOLD` | route to complex parser if exceeded |
| `HANDWRITING_SCORE_THRESHOLD` | route to manuscript lane if exceeded |
| `FORCE_MULTIMODAL_FALLBACK_THRESHOLD` | hard pages threshold |
| `ENABLE_DOCRES` | use DocRes restoration |
| `ENABLE_AUGMENTED_VIEWS` | create alternate restored variants for hard pages |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-004 PreprocessingAndRouting
REQUIRE IntakeResult, ThresholdRegistry
ENSURE PageBundle, RoutingPlan, RestoredImages, PageScores

BEGIN
    CALL Audit("PREPROCESS_STARTED", IntakeResult.job_manifest.job_id)

    SET pages <- CALL RenderOrEnumeratePages(IntakeResult.preserved_original)

    PARALLEL FOR EACH page IN pages DO
        SET native_text_ratio <- CALL EstimateNativeTextCoverage(page)
        SET page_quality <- CALL ScorePageQuality(page)
        SET layout_complexity <- CALL ScoreLayoutComplexity(page)
        SET handwriting_score <- CALL ScoreHandwritingLikelihood(page)
        SET table_density <- CALL ScoreTableDensity(page)
        SET script_profile <- CALL DetectLanguageAndScript(page)

        IF page_quality < QUALITY_RESTORE_THRESHOLD AND ENABLE_DOCRES = TRUE THEN
            SET restored_page <- CALL RestoreWithDocRes(page)
            SET restoration_applied <- TRUE
        ELSE
            SET restored_page <- page
            SET restoration_applied <- FALSE
        END IF

        IF ENABLE_AUGMENTED_VIEWS = TRUE AND
           page_quality < QUALITY_RESTORE_THRESHOLD THEN
            SET augmented_views <- CALL GenerateRestorationVariants(restored_page)
        ELSE
            SET augmented_views <- []
        END IF

        IF handwriting_score >= HANDWRITING_SCORE_THRESHOLD THEN
            SET route <- "MANUSCRIPT_LANE"
        ELSE IF native_text_ratio >= NATIVE_TEXT_MIN_RATIO AND
                layout_complexity < LAYOUT_COMPLEXITY_THRESHOLD THEN
            SET route <- "LANE_A_BULK"
        ELSE IF layout_complexity >= LAYOUT_COMPLEXITY_THRESHOLD OR
                table_density >= LAYOUT_COMPLEXITY_THRESHOLD THEN
            SET route <- "LANE_B_COMPLEX"
        ELSE IF page_quality < FORCE_MULTIMODAL_FALLBACK_THRESHOLD THEN
            SET route <- "LANE_C_MULTIMODAL_FALLBACK"
        ELSE
            SET route <- "LANE_A_BULK"
        END IF

        EMIT PageRecord(
            page_id = page.id,
            original_page = page,
            restored_page = restored_page,
            augmented_views = augmented_views,
            scores = {
                native_text_ratio,
                page_quality,
                layout_complexity,
                handwriting_score,
                table_density
            },
            script_profile = script_profile,
            route = route
        )
    END FOR

    SET flags <- CALL SummarizeRoutingFlags(PageRecordSet)

    CALL Audit("ROUTING_COMPLETED", IntakeResult.job_manifest.job_id, flags)

    RETURN {
        PageBundle = PageRecordSet,
        RoutingPlan = route assignments,
        RestoredImages = restored representations,
        PageScores = per-page scores,
        Flags = flags
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | low page quality | restore with DocRes |
| G2 | handwriting likely | manuscript lane |
| G3 | high complexity / table density | complex parser lane |
| G4 | quality too low or unresolved | multimodal fallback |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| page render failure | try alternate renderer; then isolate page |
| restoration timeout | continue with original page and lower confidence |
| handwriting detector uncertain | bias toward manuscript lane on sensitive collections |
| scoring service unavailable | route conservatively to complex lane |

## 13. Audit Events

- `PREPROCESS_STARTED`
- `PAGE_RESTORED`
- `ROUTE_ASSIGNED`
- `ROUTING_COMPLETED`

## 14. Human Escalation Conditions

No routine human review is expected here. Escalate only if:

- renderer repeatedly fails on archival formats;
- route confidence is systematically inconsistent across a collection;
- a new document class breaks page scoring assumptions.

## 15. Security / Privacy / Compliance Notes

- Restoration is a derived processing step and MUST preserve provenance.
- Controlled-tier pages MUST be restored and routed only inside the controlled boundary.
- DocRes unifies dewarping, deshadowing, appearance enhancement, deblurring, and binarization, making it well suited as a single restoration primitive for degraded material.  
  Reference: [R-DOCRES](99_REFERENCE_MAP.md#r-docres)

## 16. Metrics

- `restore_rate`
- `route_distribution`
- `route_override_rate`
- `render_failure_rate`
- `restoration_gain_delta` (before vs after extraction quality)

## 17. References

- [R-DOCRES](99_REFERENCE_MAP.md#r-docres)
