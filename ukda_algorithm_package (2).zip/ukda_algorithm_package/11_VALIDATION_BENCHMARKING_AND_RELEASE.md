---
algorithm_id: UKDA-ALG-011
title: Validation, Benchmarking, and Release
version: 1.0.0
status: normative
owner: Assurance and Release Management
depends_on:
  - 02_SYSTEM_ORCHESTRATOR.md
  - 05_DOCUMENT_EXTRACTION_LANES.md
  - 06_MANUSCRIPT_DECIPHERING.md
  - 07_REDACTION_AND_DEIDENTIFICATION.md
  - 08_SEARCH_METADATA_AND_INDEXING.md
  - 10_DEPLOYMENT_AND_MODEL_SERVING.md
last_updated: 2026-04-14
---

# ALGORITHM: Validation, Benchmarking, and Release

## 1. Purpose

Define how the platform is validated, how new models are benchmarked, and how derivatives are released safely.

## 2. Scope

Covers model evaluation, threshold tuning, regression testing, release gating, rollback, and acceptance criteria.

## 3. Inputs

- `GoldSetCleanTypescripts`
- `GoldSetMixedLayouts`
- `GoldSetDegradedManuscripts`
- `CandidateModels`
- `CurrentProductionModels`
- `ReleaseArtifacts`

## 4. Outputs

- `BenchmarkReport`
- `PromotionDecision`
- `ReleaseDecision`
- `RollbackPlan`

## 5. Dependencies

- evaluation harness;
- approved gold sets;
- disclosure review;
- release workflow.

## 6. Preconditions

- gold sets are curated and versioned;
- candidate models are registered;
- current production baseline exists.

## 7. Postconditions

- no model is promoted without comparative evidence;
- release decisions are documented;
- rollback path exists for every promoted model.

## 8. Invariants

1. Clean, mixed-layout, and degraded-manuscript tracks MUST all be benchmarked.
2. Release MUST fail closed when disclosure control is pending.
3. Benchmarking MUST compare against production baseline, not absolute scores alone.
4. Manuscript evaluation MUST measure both line-level and page-level performance.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `PROMOTION_REQUIRES_ALL_TRACKS_PASS` | boolean |
| `CER_MAX` | proposed manuscript error ceiling |
| `WER_MAX` | proposed manuscript word error ceiling |
| `REDACTION_RECALL_MIN` | proposed minimum recall |
| `SEARCH_NDCG_MIN` | proposed search relevance floor |
| `EXCEPTION_RATE_MAX` | max acceptable unresolved exceptions |
| `ROLLBACK_ON_REGRESSION` | boolean |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-011 ValidationBenchmarkingAndRelease
REQUIRE GoldSets, CandidateModels, CurrentProductionModels, ReleaseArtifacts
ENSURE BenchmarkReport, PromotionDecision, ReleaseDecision, RollbackPlan

BEGIN
    CALL Audit("BENCHMARK_STARTED", CandidateModels.version_set)

    SET clean_results <- CALL EvaluateCleanTrack(CandidateModels, GoldSetCleanTypescripts)
    SET mixed_results <- CALL EvaluateMixedLayoutTrack(CandidateModels, GoldSetMixedLayouts)
    SET manuscript_results <- CALL EvaluateManuscriptTrack(CandidateModels, GoldSetDegradedManuscripts)
    SET redaction_results <- CALL EvaluateRedactionTrack(CandidateModels, GoldSets)
    SET search_results <- CALL EvaluateSearchTrack(CandidateModels, GoldSets)

    SET benchmark_report <- CALL CompareAgainstBaseline(
        clean_results,
        mixed_results,
        manuscript_results,
        redaction_results,
        search_results,
        CurrentProductionModels
    )

    IF benchmark_report.has_regression = TRUE AND ROLLBACK_ON_REGRESSION = TRUE THEN
        SET promotion_decision <- "REJECT"
    ELSE IF benchmark_report.passes_all_required_tracks = TRUE THEN
        SET promotion_decision <- "APPROVE"
    ELSE
        SET promotion_decision <- "REJECT"
    END IF

    IF ReleaseArtifacts.access_tier = "CONTROLLED" THEN
        SET release_decision <- CALL RequireSafeOutputReview(ReleaseArtifacts)
    ELSE
        SET release_decision <- CALL StandardReleaseCheck(ReleaseArtifacts)
    END IF

    SET rollback_plan <- CALL BuildRollbackPlan(CurrentProductionModels)

    CALL Audit("BENCHMARK_COMPLETED", promotion_decision, release_decision)

    RETURN {
        BenchmarkReport = benchmark_report,
        PromotionDecision = promotion_decision,
        ReleaseDecision = release_decision,
        RollbackPlan = rollback_plan
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | parser candidate beats baseline on clean/mixed/manuscript | eligible for promotion |
| G2 | redaction recall below floor | reject |
| G3 | search relevance degrades | reject |
| G4 | controlled release requested | safe-output review |
| G5 | production regression detected | rollback or reject |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| gold set drift | freeze gold set version and rerun |
| benchmark harness failure | no promotion |
| safe-output queue unavailable | hold release |
| release artifact mismatch | rebuild from signed restricted master |

## 13. Audit Events

- `BENCHMARK_STARTED`
- `TRACK_EVALUATED`
- `BASELINE_COMPARISON_COMPLETED`
- `PROMOTION_APPROVED`
- `PROMOTION_REJECTED`
- `SAFE_OUTPUT_REVIEW_REQUESTED`
- `BENCHMARK_COMPLETED`

## 14. Human Escalation Conditions

Human oversight is expected for:

- gold-set curation;
- formal promotion sign-off for core models;
- controlled output release;
- rollback after a production incident.

## 15. Security / Privacy / Compliance Notes

- OmniDocBench provides document-parsing evaluation dimensions and metrics such as NED, BLEU, METEOR, TEDS, and COCODet.  
  Reference: [R-OMNIDOCBENCH](99_REFERENCE_MAP.md#r-omnidocbench)
- SecureLab outputs require statistical disclosure control review before removal from the secure environment.  
  References: [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs), [R-SECURELAB-FAQ](99_REFERENCE_MAP.md#r-securelab-faq)
- Training requirements for SecureLab include data security and statistical disclosure control principles.  
  Reference: [R-SECURELAB-TRAINING](99_REFERENCE_MAP.md#r-securelab-training)

## 16. Metrics

Recommended benchmark families:

- extraction:
  - `NED`
  - `TEDS`
  - `structure_integrity`
- manuscripts:
  - `CER`
  - `WER`
  - `line_accept_rate`
- redaction:
  - `recall`
  - `precision`
  - `high_risk_miss_rate`
- search:
  - `MRR`
  - `nDCG@10`
  - `Recall@k`
- operations:
  - `exception_rate`
  - `human_minutes_per_100_pages`
  - `pages_per_hour`

## 17. References

- [R-OMNIDOCBENCH](99_REFERENCE_MAP.md#r-omnidocbench)
- [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs)
- [R-SECURELAB-FAQ](99_REFERENCE_MAP.md#r-securelab-faq)
- [R-SECURELAB-TRAINING](99_REFERENCE_MAP.md#r-securelab-training)
