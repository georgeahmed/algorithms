---
algorithm_id: UKDA-ALG-002
title: End-to-End System Orchestrator
version: 1.0.0
status: normative
owner: Platform Architecture
depends_on:
  - 03_INTAKE_AND_CLASSIFICATION.md
  - 04_PREPROCESSING_AND_ROUTING.md
  - 05_DOCUMENT_EXTRACTION_LANES.md
  - 06_MANUSCRIPT_DECIPHERING.md
  - 07_REDACTION_AND_DEIDENTIFICATION.md
  - 08_SEARCH_METADATA_AND_INDEXING.md
  - 09_SECURITY_COMPLIANCE_AND_AUDIT.md
  - 10_DEPLOYMENT_AND_MODEL_SERVING.md
  - 11_VALIDATION_BENCHMARKING_AND_RELEASE.md
last_updated: 2026-04-14
---

# ALGORITHM: End-to-End System Orchestrator

## 1. Purpose

Define the full workflow for secure, highly automated document processing at UKDA from intake to release and search delivery.

## 2. Scope

This algorithm governs:

- born-digital documents;
- scanned typescripts;
- complex multi-layout pages;
- highly degraded manuscripts;
- sensitive and controlled archival material.

## 3. Inputs

- `IntakePackage`
  - source files
  - depositor metadata
  - legal / contractual restrictions
  - collection identifier
- `PolicyRegistry`
- `ThresholdRegistry`
- `ModelRegistry`
- `StorageRegistry`
- `ReleaseRules`

## 4. Outputs

- `PreservedOriginal`
- `CanonicalDocumentGraph`
- `RestrictedMasterDerivative`
- `ResearchReleaseDerivative` or `NoReleaseDecision`
- `SearchArtifacts`
- `AuditLedgerEntries`
- `ExceptionQueueItems`

## 5. Dependencies

- [03_INTAKE_AND_CLASSIFICATION.md](03_INTAKE_AND_CLASSIFICATION.md)
- [04_PREPROCESSING_AND_ROUTING.md](04_PREPROCESSING_AND_ROUTING.md)
- [05_DOCUMENT_EXTRACTION_LANES.md](05_DOCUMENT_EXTRACTION_LANES.md)
- [06_MANUSCRIPT_DECIPHERING.md](06_MANUSCRIPT_DECIPHERING.md)
- [07_REDACTION_AND_DEIDENTIFICATION.md](07_REDACTION_AND_DEIDENTIFICATION.md)
- [08_SEARCH_METADATA_AND_INDEXING.md](08_SEARCH_METADATA_AND_INDEXING.md)
- [09_SECURITY_COMPLIANCE_AND_AUDIT.md](09_SECURITY_COMPLIANCE_AND_AUDIT.md)
- [10_DEPLOYMENT_AND_MODEL_SERVING.md](10_DEPLOYMENT_AND_MODEL_SERVING.md)
- [11_VALIDATION_BENCHMARKING_AND_RELEASE.md](11_VALIDATION_BENCHMARKING_AND_RELEASE.md)

## 6. Preconditions

- intake gateway is online;
- storage, audit, and model registries are available;
- policy mappings for access tiers exist;
- approved local model set exists for the relevant data tier.

## 7. Postconditions

- every processed document has a preserved original;
- every extracted token or region is traceable to a page/line/block when available;
- every released output has passed its required controls;
- every exception has a reason code.

## 8. Invariants

1. Controlled-tier content MUST NOT leave the controlled boundary except through approved output release.
2. All AI inference on controlled material MUST run locally or enclave-locally.
3. Every derivative MUST retain provenance.
4. Human review MUST remain limited to defined checkpoints.
5. No page may bypass classification, audit, or release control.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `HARD_STOP_ON_MALWARE` | reject on malware detection |
| `ENABLE_MANUSCRIPT_LANE` | enable specialist handwriting pipeline |
| `ENABLE_CHALLENGER_PARSER` | run optional challenger parser (e.g., PaddleOCR-VL-1.5) |
| `DOC_ACCEPT_THRESHOLD` | minimum confidence for automatic acceptance |
| `HTR_ACCEPT_THRESHOLD` | minimum confidence for manuscript auto-accept |
| `REDACTION_REVIEW_THRESHOLD` | ambiguity threshold for human redaction review |
| `CONTROLLED_RELEASE_MODE` | requires safe-output review |
| `INDEX_BY_TIER` | separate indexes by access tier |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-002 SystemOrchestrator
REQUIRE IntakePackage, PolicyRegistry, ThresholdRegistry, ModelRegistry, ReleaseRules
ENSURE PreservedOriginal, CanonicalDocumentGraph, Derivatives, SearchArtifacts, AuditLedgerEntries

BEGIN
    CALL Audit("JOB_RECEIVED", IntakePackage.job_id)

    SET IntakeResult <- CALL IntakeAndClassification(IntakePackage)

    ASSERT IntakeResult.status = "ACCEPTED"
    EMIT PreservedOriginal <- IntakeResult.preserved_original

    SET PrepResult <- CALL PreprocessingAndRouting(IntakeResult)

    SET ExtractionResult <- CALL DocumentExtractionLanes(PrepResult)

    IF PrepResult.flags.contains("MANUSCRIPT_REQUIRED") OR
       ExtractionResult.flags.contains("HANDWRITING_UNRESOLVED") THEN
        SET ExtractionResult <- CALL ManuscriptDeciphering(PrepResult, ExtractionResult)
    END IF

    SET RedactionResult <- CALL RedactionAndDeidentification(ExtractionResult, IntakeResult.access_tier)

    SET IndexResult <- CALL SearchMetadataAndIndexing(RedactionResult, IntakeResult.access_tier)

    CALL SecurityComplianceAndAudit(
        IntakeResult,
        PrepResult,
        ExtractionResult,
        RedactionResult,
        IndexResult
    )

    SET ReleaseResult <- CALL ValidationBenchmarkingAndRelease(
        IntakeResult,
        ExtractionResult,
        RedactionResult,
        IndexResult,
        ReleaseRules
    )

    CALL Audit("JOB_COMPLETED", IntakePackage.job_id, ReleaseResult.status)

    RETURN {
        PreservedOriginal,
        CanonicalDocumentGraph = ExtractionResult.canonical_graph,
        RestrictedMasterDerivative = RedactionResult.restricted_master,
        ResearchReleaseDerivative = ReleaseResult.release_derivative,
        SearchArtifacts = IndexResult.search_artifacts,
        AuditLedgerEntries = ReleaseResult.audit_entries,
        ExceptionQueueItems = ReleaseResult.exception_items
    }
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | intake invalid / malware / unsupported | reject or quarantine |
| G2 | access tier unresolved | escalate to governance |
| G3 | route indicates manuscript | invoke specialist handwriting lane |
| G4 | extraction confidence below threshold | retry/fallback/escalate |
| G5 | redaction ambiguity above threshold | human review |
| G6 | controlled output release requested | safe-output review required |

## 12. Failure Modes and Recovery

| Failure | Response |
|---|---|
| malware detected | quarantine source; no downstream processing |
| storage write failure | stop job; retry idempotently |
| OCR/VLM timeout | retry on alternate worker; then fallback lane |
| canonical graph schema violation | fail closed; move to exception queue |
| redaction engine disagreement | mark high risk; escalate |
| index publication failure | preserve derivatives; retry index build |

## 13. Audit Events

- `JOB_RECEIVED`
- `INTAKE_ACCEPTED`
- `TIER_ASSIGNED`
- `PREPROCESS_STARTED`
- `ROUTE_ASSIGNED`
- `EXTRACTION_COMPLETED`
- `MANUSCRIPT_LANE_ENTERED`
- `REDACTION_COMPLETED`
- `INDEX_UPDATED`
- `SAFE_OUTPUT_REVIEW_REQUESTED`
- `JOB_COMPLETED`
- `JOB_FAILED`

## 14. Human Escalation Conditions

Humans MAY intervene only when one of these is true:

1. new collection or script onboarding is required;
2. access tier or policy interpretation is unresolved;
3. manuscript consensus remains below `HTR_ACCEPT_THRESHOLD`;
4. redaction ambiguity exceeds `REDACTION_REVIEW_THRESHOLD`;
5. controlled output must be released externally.

## 15. Security / Privacy / Compliance Notes

- Access tiering aligns with UK Data Service open / safeguarded / controlled practice.  
  Reference: [R-UKDS-ACCESS](99_REFERENCE_MAP.md#r-ukds-access)
- Controlled processing assumes a SecureLab-style boundary and output checking.  
  References: [R-SECURELAB](99_REFERENCE_MAP.md#r-securelab), [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs)
- DPIA/governance triggers apply for high-risk or new-technology personal-data processing.  
  References: [R-ESSEX-DPIA](99_REFERENCE_MAP.md#r-essex-dpia), [R-ESSEX-DP-POLICY](99_REFERENCE_MAP.md#r-essex-dp-policy)
- AI-system security follows NCSC secure AI system development guidance.  
  Reference: [R-NCSC-AI](99_REFERENCE_MAP.md#r-ncsc-ai)

## 16. Metrics

- `pages_per_hour`
- `documents_per_day`
- `exception_rate`
- `human_minutes_per_100_pages`
- `tier_misclassification_rate`
- `release_rejection_rate`
- `mean_processing_cost_per_page`

## 17. References

- [R-UKDS-ACCESS](99_REFERENCE_MAP.md#r-ukds-access)
- [R-SECURELAB](99_REFERENCE_MAP.md#r-securelab)
- [R-SAFE-OUTPUTS](99_REFERENCE_MAP.md#r-safe-outputs)
- [R-ESSEX-DPIA](99_REFERENCE_MAP.md#r-essex-dpia)
- [R-ESSEX-DP-POLICY](99_REFERENCE_MAP.md#r-essex-dp-policy)
- [R-NCSC-AI](99_REFERENCE_MAP.md#r-ncsc-ai)
