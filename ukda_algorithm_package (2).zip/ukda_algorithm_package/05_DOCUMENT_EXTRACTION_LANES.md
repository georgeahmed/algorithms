---
algorithm_id: UKDA-ALG-005
title: Document Extraction Lanes
version: 1.0.0
status: normative
owner: Document AI Pipeline
depends_on:
  - 04_PREPROCESSING_AND_ROUTING.md
last_updated: 2026-04-14
---

# ALGORITHM: Document Extraction Lanes

## 1. Purpose

Run the correct extraction engine for each page, normalize outputs into one canonical document graph, and minimize expensive multimodal inference.

## 2. Scope

Covers non-manuscript extraction for:

- born-digital pages;
- clean scans;
- tables and complex layouts;
- hard pages requiring VLM fallback.

## 3. Inputs

- `PageBundle`
- `RoutingPlan`
- `ModelRegistry`
- `SchemaRegistry`

## 4. Outputs

- `ExtractionResult.canonical_graph`
- `ExtractionResult.page_outputs`
- `ExtractionResult.flags`
- `ExtractionResult.confidence_summary`

## 5. Dependencies

- `Docling`
- `Surya`
- `MinerU`
- `Qwen3-VL`
- optional challenger parser: `PaddleOCR-VL-1.5`
- canonical schema validator

## 6. Preconditions

- pages rendered and routed;
- model versions approved in registry;
- access-tier-appropriate worker pool available.

## 7. Postconditions

- every page is represented in a canonical graph;
- coordinates, structure, confidence, and provenance are attached;
- pages not meeting confidence thresholds are flagged.

## 8. Invariants

1. All lanes MUST emit the same canonical schema.
2. Multimodal fallback MUST be used sparingly.
3. Native text MUST be preferred where reliable.
4. No parser output may bypass schema validation.

## 9. Configuration Parameters

| Parameter | Meaning |
|---|---|
| `LANE_A_MODELS` | default `["native_text", "docling", "surya"]` |
| `LANE_B_PRIMARY` | default `MinerU` |
| `LANE_B_CHALLENGER` | optional `PaddleOCR-VL-1.5` |
| `LANE_C_MODEL` | default `Qwen3-VL` |
| `SCHEMA_ENFORCEMENT_MODE` | strict / permissive |
| `PARSE_ACCEPT_THRESHOLD` | minimum parse confidence |
| `ENABLE_CHALLENGER_COMPARISON` | compare Lane B outputs |
| `VLM_JSON_SCHEMA_MODE` | structured output constraint |

## 10. Procedure

```text
ALGORITHM UKDA-ALG-005 DocumentExtractionLanes
REQUIRE PageBundle, RoutingPlan, ModelRegistry, SchemaRegistry
ENSURE ExtractionResult

BEGIN
    CALL Audit("EXTRACTION_STARTED", count(PageBundle))

    PARALLEL FOR EACH page_record IN PageBundle DO
        IF page_record.route = "LANE_A_BULK" THEN
            SET raw_output <- CALL LaneA_Bulk(page_record)
        ELSE IF page_record.route = "LANE_B_COMPLEX" THEN
            SET raw_output <- CALL LaneB_Complex(page_record)
        ELSE IF page_record.route = "LANE_C_MULTIMODAL_FALLBACK" THEN
            SET raw_output <- CALL LaneC_MultimodalFallback(page_record)
        ELSE IF page_record.route = "MANUSCRIPT_LANE" THEN
            SET raw_output <- CALL MinimalPlaceholder(page_record)
        ELSE
            FAIL "UNKNOWN_ROUTE"
        END IF

        SET validated_output <- CALL ValidateAgainstCanonicalSchema(raw_output, SchemaRegistry)

        IF validated_output.confidence < PARSE_ACCEPT_THRESHOLD THEN
            SET validated_output.flags += "LOW_CONFIDENCE"
        END IF

        EMIT PageExtraction(page_record.page_id, validated_output)
    END FOR

    SET canonical_graph <- CALL MergePageExtractions(PageExtractionSet)
    SET flags <- CALL SummarizeExtractionFlags(PageExtractionSet)

    CALL Audit("EXTRACTION_COMPLETED", flags)

    RETURN {
        canonical_graph,
        page_outputs = PageExtractionSet,
        flags,
        confidence_summary = CALL AggregateConfidence(PageExtractionSet)
    }
END
```

### 10.1 Lane A — bulk extraction

```text
SUBROUTINE LaneA_Bulk(page_record)
BEGIN
    IF page_record.scores.native_text_ratio > 0 THEN
        SET native_text <- CALL ExtractEmbeddedText(page_record.original_page)
    ELSE
        SET native_text <- NULL
    END IF

    SET docling_output <- CALL DoclingParse(page_record.restored_page, native_text)
    SET surya_output <- CALL SuryaOCRLayoutTables(page_record.restored_page)

    SET fused_output <- CALL FuseBulkOutputs(docling_output, surya_output, native_text)

    RETURN MapToCanonicalGraph(fused_output, page_record)
END
```

### 10.2 Lane B — complex documents

```text
SUBROUTINE LaneB_Complex(page_record)
BEGIN
    SET primary_output <- CALL MinerUParse(page_record.restored_page)

    IF ENABLE_CHALLENGER_COMPARISON = TRUE THEN
        SET challenger_output <- CALL PaddleOCRVLParse(page_record.restored_page)
        SET selected_output <- CALL SelectBestComplexParse(
            primary_output,
            challenger_output,
            criteria = ["coverage", "table_quality", "structure_integrity", "confidence"]
        )
    ELSE
        SET selected_output <- primary_output
    END IF

    RETURN MapToCanonicalGraph(selected_output, page_record)
END
```

### 10.3 Lane C — multimodal fallback

```text
SUBROUTINE LaneC_MultimodalFallback(page_record)
BEGIN
    SET qwen_prompt <- CALL BuildStrictParsingPrompt(
        require_coordinates = TRUE,
        require_uncertainty_markers = TRUE,
        output_schema = "CANONICAL_JSON"
    )

    SET qwen_output <- CALL Qwen3VLParse(
        image = page_record.restored_page,
        prompt = qwen_prompt,
        schema_mode = VLM_JSON_SCHEMA_MODE
    )

    RETURN MapToCanonicalGraph(qwen_output, page_record)
END
```

## 11. Decision Gates

| Gate | Condition | Action |
|---|---|---|
| G1 | native text present and layout simple | Lane A |
| G2 | complex layout / dense tables / scientific structure | Lane B |
| G3 | parse unresolved or image severely degraded | Lane C |
| G4 | handwriting indicated | defer to manuscript lane |

## 12. Failure Modes and Recovery

| Failure | Recovery |
|---|---|
| native text corrupted | ignore native layer; OCR page |
| Docling parse incomplete | fuse with Surya / escalate to Lane B |
| MinerU malformed structure | compare with challenger or escalate to Lane C |
| Qwen3-VL hallucinates fields | reject schema; retry with stricter prompt; then escalate |
| canonical merge conflict | preserve alternatives and flag |

## 13. Audit Events

- `EXTRACTION_STARTED`
- `LANE_A_USED`
- `LANE_B_USED`
- `LANE_B_CHALLENGER_USED`
- `LANE_C_USED`
- `SCHEMA_VALIDATION_FAILED`
- `EXTRACTION_COMPLETED`

## 14. Human Escalation Conditions

Humans SHOULD NOT review standard pages.
Escalate only when:

- all applicable lanes fail schema validation;
- table fidelity on a high-value page remains unacceptable;
- repeated hallucination or parse collapse occurs on a collection.

## 15. Security / Privacy / Compliance Notes

- Docling is a local document-conversion toolkit with structured output and modest hardware requirements.  
  Reference: [R-DOCLING](99_REFERENCE_MAP.md#r-docling)
- Surya provides OCR, line detection, layout, reading order, table recognition, and LaTeX OCR across many languages.  
  Reference: [R-SURYA](99_REFERENCE_MAP.md#r-surya)
- MinerU converts complex documents into machine-readable Markdown/JSON and is suited to high-structure parsing workloads.  
  Reference: [R-MINERU](99_REFERENCE_MAP.md#r-mineru)
- Qwen3-VL expands OCR robustness under blur and tilt and supports stronger document parsing.  
  Reference: [R-QWEN3-VL](99_REFERENCE_MAP.md#r-qwen3-vl)
- PaddleOCR-VL-1.5 is included as an optional challenger because its maintainers report 94.5% on OmniDocBench v1.5 and strong robustness on skew/warping/scanning/illumination scenarios.  
  References: [R-PADDLEOCR-VL](99_REFERENCE_MAP.md#r-paddleocr-vl), [R-OMNIDOCBENCH](99_REFERENCE_MAP.md#r-omnidocbench)

## 16. Metrics

- `lane_a_share`
- `lane_b_share`
- `lane_c_share`
- `schema_pass_rate`
- `table_fidelity_score`
- `structure_integrity_score`
- `fallback_rate`

## 17. References

- [R-DOCLING](99_REFERENCE_MAP.md#r-docling)
- [R-SURYA](99_REFERENCE_MAP.md#r-surya)
- [R-MINERU](99_REFERENCE_MAP.md#r-mineru)
- [R-QWEN3-VL](99_REFERENCE_MAP.md#r-qwen3-vl)
- [R-PADDLEOCR-VL](99_REFERENCE_MAP.md#r-paddleocr-vl)
- [R-OMNIDOCBENCH](99_REFERENCE_MAP.md#r-omnidocbench)
